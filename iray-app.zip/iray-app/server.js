// ============================================================================
// Iray App — espaço de chat privado a dois, instalável no telemóvel (PWA).
// Um único servidor Node (Express + WebSocket), sem dependência de
// WhatsApp/Telegram — vocês falam directamente com o vosso próprio servidor.
// ============================================================================

require('dotenv').config();
const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const axios = require('axios');
const { WebSocketServer } = require('ws');
const { v4: uuidv4 } = require('uuid');
const webpush = require('web-push');

const CONFIG = {
    // Nomes e PINs fixos aqui, ao estilo do Nano Bot — o PIN é o que dá
    // acesso à app (não há ecrã a mostrar os nomes antes de entrar).
    people: [
        { id: 'a', name: 'Yanick', pin: '8414' },
        { id: 'b', name: 'Iracema', pin: '8614' }
    ],
    groqApiKey: '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',
    groqBaseUrl: 'https://api.groq.com/openai/v1',
    groqModel: 'openai/gpt-oss-120b',
    dataFile: path.join(__dirname, 'data', 'chat.json'),
    subsFile: path.join(__dirname, 'data', 'subscricoes.json'),
    maxHistory: 500,

    // Chaves VAPID — identificam este servidor perante os serviços de push
    // do browser (Google/Mozilla/Apple). Geradas uma vez, ficam fixas aqui;
    // a pública também é usada no browser (é suposto ser pública).
    vapidPublicKey: 'BOGAQqou3HDPnaWARJsskT84wPI1tpK35eqWXz_mPxxJU0l8BTfR0x1I2hzOp-XhY3UXtF9TwcjXg5auwpa-8pU',
    vapidPrivateKey: '4q9CXGMlPJ4tIrUGKHaaZ4IZgihP2Ah1W74Jv-JBKVQ'
};

webpush.setVapidDetails('mailto:iray@example.com', CONFIG.vapidPublicKey, CONFIG.vapidPrivateKey);

if (!fs.existsSync(path.dirname(CONFIG.dataFile))) fs.mkdirSync(path.dirname(CONFIG.dataFile), { recursive: true });
if (!fs.existsSync(CONFIG.dataFile)) fs.writeFileSync(CONFIG.dataFile, JSON.stringify({ messages: [] }, null, 2));
const audioDir = path.join(__dirname, 'data', 'audio');
if (!fs.existsSync(audioDir)) fs.mkdirSync(audioDir, { recursive: true });
if (!fs.existsSync(CONFIG.subsFile)) fs.writeFileSync(CONFIG.subsFile, JSON.stringify({}, null, 2));

function lerHistorico() {
    try { return JSON.parse(fs.readFileSync(CONFIG.dataFile, 'utf8')); } catch { return { messages: [] }; }
}
function gravarHistorico(db) {
    db.messages = db.messages.slice(-CONFIG.maxHistory);
    fs.writeFileSync(CONFIG.dataFile, JSON.stringify(db, null, 2));
}

// Subscrições de push por pessoa: { [personId]: [subscription, ...] } —
// lista porque a mesma pessoa pode instalar em mais que um telemóvel.
function lerSubs() {
    try { return JSON.parse(fs.readFileSync(CONFIG.subsFile, 'utf8')); } catch { return {}; }
}
function gravarSubs(subs) { fs.writeFileSync(CONFIG.subsFile, JSON.stringify(subs, null, 2)); }
function guardarSubscricao(personId, subscription) {
    const subs = lerSubs();
    if (!subs[personId]) subs[personId] = [];
    const jaExiste = subs[personId].some(s => s.endpoint === subscription.endpoint);
    if (!jaExiste) subs[personId].push(subscription);
    gravarSubs(subs);
}
function removerSubscricao(personId, endpoint) {
    const subs = lerSubs();
    if (!subs[personId]) return;
    subs[personId] = subs[personId].filter(s => s.endpoint !== endpoint);
    gravarSubs(subs);
}

// tokens simples em memória: token -> { id, name }
const sessoes = new Map();

// presença em tempo real: id -> { status, ts } — não é gravado em disco,
// é só o estado actual de cada um enquanto o servidor está de pé.
const ESTADOS_VALIDOS = ['disponivel', 'caminho', 'ocupado', 'dormir'];
const presenca = new Map(CONFIG.people.map(p => [p.id, { status: 'disponivel', ts: Date.now() }]));

function outraPessoa(id) { return CONFIG.people.find(p => p.id !== id); }
function pessoaPorId(id) { return CONFIG.people.find(p => p.id === id); }
function estadoPresenca() {
    return CONFIG.people.map(p => ({ id: p.id, name: p.name, ...presenca.get(p.id) }));
}

// Quem está ligado agora mesmo (pode ter mais que uma aba/telemóvel aberto)
// e quando é que cada um esteve online pela última vez.
const conectados = new Map(CONFIG.people.map(p => [p.id, new Set()]));
const ultimaVezVisto = new Map(CONFIG.people.map(p => [p.id, null]));

function estaOnline(id) { return (conectados.get(id)?.size || 0) > 0; }
function estadoOnline() {
    return CONFIG.people.map(p => ({ id: p.id, online: estaOnline(p.id), ultimaVez: ultimaVezVisto.get(p.id) }));
}

// =================== IRAY (IA) ===================
async function perguntarIray(historicoRecente) {
    if (!CONFIG.groqApiKey) {
        return 'Ainda não tenho a minha chave de IA configurada (falta GROQ_API_KEY) — mas continuo aqui a guardar as vossas mensagens 💛';
    }
    const nomes = CONFIG.people.map(p => p.name).join(' e ');
    const statusTexto = estadoPresenca().map(p => `${p.name}: ${p.status}`).join(', ');
    const systemPrompt = `Tu és o Iray, um assistente caloroso e presente que vive dentro do espaço privado de ${nomes}. `
        + `Respondes em português, de forma breve, natural e afectuosa, sem exageros nem emojis a mais. `
        + `Não inventas factos sobre a relação deles — só respondes ao que é dito na conversa. `
        + `Estado actual de presença (informação real, podes usar): ${statusTexto}.`;

    const messages = [
        { role: 'system', content: systemPrompt },
        ...historicoRecente.map(m => ({
            role: m.autor === 'iray' ? 'assistant' : 'user',
            content: m.autor === 'iray' ? m.texto : `${m.nome}: ${m.texto}`
        }))
    ];

    try {
        const resp = await axios.post(`${CONFIG.groqBaseUrl}/chat/completions`, {
            model: CONFIG.groqModel,
            messages,
            max_tokens: 300,
            temperature: 0.8
        }, {
            headers: { 'Authorization': `Bearer ${CONFIG.groqApiKey}`, 'Content-Type': 'application/json' },
            timeout: 20000
        });
        return resp.data?.choices?.[0]?.message?.content?.trim() || 'Hmm, não consegui pensar numa resposta agora.';
    } catch (error) {
        console.error('Erro Groq:', error.response?.data || error.message);
        return 'Tive um problema a pensar agora — tenta outra vez daqui a pouco.';
    }
}

// =================== APP HTTP ===================
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/media', express.static(path.join(__dirname, 'data', 'audio')));

function autenticar(req, res, next) {
    const token = req.headers['x-token'];
    const sessao = sessoes.get(token);
    if (!sessao) return res.status(401).json({ erro: 'Sessão inválida.' });
    req.sessao = sessao;
    next();
}

app.post('/api/login', (req, res) => {
    const { pin } = req.body || {};
    const pessoa = CONFIG.people.find(p => String(p.pin) === String(pin));
    if (!pessoa) {
        return res.status(401).json({ erro: 'PIN incorreto.' });
    }
    const token = uuidv4();
    sessoes.set(token, { id: pessoa.id, name: pessoa.name });
    res.json({ token, name: pessoa.name, id: pessoa.id });
});

app.get('/api/mensagens', autenticar, (req, res) => {
    res.json(lerHistorico().messages);
});

app.get('/api/companheiro', autenticar, (req, res) => {
    const outro = outraPessoa(req.sessao.id);
    res.json({ id: outro.id, name: outro.name });
});

app.get('/api/presenca', autenticar, (req, res) => {
    res.json(estadoPresenca());
});

app.get('/api/online', autenticar, (req, res) => {
    res.json(estadoOnline());
});

app.get('/api/push/chave-publica', (req, res) => {
    res.json({ chave: CONFIG.vapidPublicKey });
});

app.post('/api/push/subscrever', autenticar, (req, res) => {
    const subscription = req.body;
    if (!subscription || !subscription.endpoint) return res.status(400).json({ erro: 'Subscrição inválida.' });
    guardarSubscricao(req.sessao.id, subscription);
    res.json({ ok: true });
});

// Upload de áudio: recebe o ficheiro em bruto (gravado no browser),
// guarda em disco e devolve o URL para anexar à mensagem.
app.post('/api/audio', autenticar, express.raw({ type: () => true, limit: '15mb' }), (req, res) => {
    if (!req.body || !req.body.length) return res.status(400).json({ erro: 'Áudio vazio.' });
    const nomeFicheiro = `${uuidv4()}.webm`;
    fs.writeFileSync(path.join(__dirname, 'data', 'audio', nomeFicheiro), req.body);
    res.json({ url: `/media/${nomeFicheiro}` });
});

const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

function broadcast(msg) {
    const payload = JSON.stringify(msg);
    wss.clients.forEach(client => {
        if (client.readyState === 1) client.send(payload);
    });
}

// Avisa uma pessoa de duas formas ao mesmo tempo: pelo WebSocket (se a app
// dela estiver aberta nesse momento — mais rápido) e por push a sério
// (funciona mesmo com a app completamente fechada). O service worker usa a
// mesma "tag" para as duas, para não duplicar o aviso se ambas chegarem.
async function avisar(paraId, titulo, corpo) {
    broadcast({ tipo: 'notificar', paraId, titulo, corpo });

    const subs = lerSubs()[paraId] || [];
    const payload = JSON.stringify({ titulo, corpo });
    for (const sub of subs) {
        try {
            await webpush.sendNotification(sub, payload);
        } catch (error) {
            if (error.statusCode === 404 || error.statusCode === 410) {
                // subscrição expirada/inválida (ex: app reinstalada) — limpa-a
                removerSubscricao(paraId, sub.endpoint);
            } else {
                console.error('Erro ao enviar push:', error.statusCode, error.body);
            }
        }
    }
}

// Quando uma pessoa liga (ou já estava ligada), qualquer mensagem que a
// outra lhe tenha mandado passa de "enviada" a "entregue" — tal como o
// segundo certo do WhatsApp.
function marcarEntregues(paraId) {
    const db = lerHistorico();
    let mudou = false;
    const idsMarcados = [];
    for (const m of db.messages) {
        if (m.autor !== paraId && m.autor !== 'iray' && m.estado === 'enviada') {
            m.estado = 'entregue';
            idsMarcados.push(m.id);
            mudou = true;
        }
    }
    if (mudou) {
        gravarHistorico(db);
        broadcast({ tipo: 'estado', ids: idsMarcados, estado: 'entregue' });
    }
}

wss.on('connection', (ws, req) => {
    const url = new URL(req.url, 'http://localhost');
    const token = url.searchParams.get('token');
    const sessao = sessoes.get(token);
    if (!sessao) { ws.close(4001, 'Sessão inválida'); return; }

    conectados.get(sessao.id).add(ws);
    broadcast({ tipo: 'online', estado: estadoOnline() });

    // Ao ligar, manda logo o estado de presença e de online/offline actual.
    ws.send(JSON.stringify({ tipo: 'presenca', estado: estadoPresenca() }));
    ws.send(JSON.stringify({ tipo: 'online', estado: estadoOnline() }));

    // Mensagens que a outra pessoa mandou enquanto isto estava offline
    // ficam automaticamente "entregues" agora que a app abriu.
    marcarEntregues(sessao.id);

    ws.on('close', () => {
        conectados.get(sessao.id).delete(ws);
        if (!estaOnline(sessao.id)) {
            ultimaVezVisto.set(sessao.id, Date.now());
        }
        broadcast({ tipo: 'online', estado: estadoOnline() });
    });

    ws.on('message', async (raw) => {
        let data;
        try { data = JSON.parse(raw); } catch { return; }

        // --- "A escrever..." / "A gravar áudio..." — só reenvia à outra
        // pessoa, não fica guardado em lado nenhum (é só um instante). ---
        if (data.tipo === 'escrevendo' || data.tipo === 'gravando') {
            const outro = outraPessoa(sessao.id);
            broadcast({ tipo: data.tipo, paraId: outro.id, de: sessao.name, activo: !!data.activo });
            return;
        }

        // --- A pessoa abriu/está a ver o chat: marca mensagens como lidas ---
        if (data.tipo === 'lido') {
            const db = lerHistorico();
            let mudou = false;
            const idsMarcados = [];
            for (const m of db.messages) {
                if (m.autor !== sessao.id && m.autor !== 'iray' && m.estado !== 'lida') {
                    m.estado = 'lida';
                    idsMarcados.push(m.id);
                    mudou = true;
                }
            }
            if (mudou) {
                gravarHistorico(db);
                broadcast({ tipo: 'estado', ids: idsMarcados, estado: 'lida' });
            }
            return;
        }

        // --- Mudança de estado (disponível / a caminho / ocupado/a / a dormir) ---
        if (data.tipo === 'status') {
            if (!ESTADOS_VALIDOS.includes(data.valor)) return;
            presenca.set(sessao.id, { status: data.valor, ts: Date.now() });
            broadcast({ tipo: 'presenca', estado: estadoPresenca() });
            return;
        }

        // --- "Pensando em ti" — um toque, sem escrever nada ---
        if (data.tipo === 'pensando') {
            const outro = outraPessoa(sessao.id);
            const msg = { id: uuidv4(), autor: sessao.id, nome: sessao.name, texto: `💭 ${sessao.name} está a pensar em ti`, carinho: true, estado: 'enviada', ts: Date.now() };
            const db = lerHistorico();
            db.messages.push(msg);
            gravarHistorico(db);
            broadcast({ tipo: 'mensagem', msg });
            if (estaOnline(outro.id)) marcarEntregues(outro.id);
            avisar(outro.id, sessao.name, `${sessao.name} está a pensar em ti 😍`);
            return;
        }

        // --- Mensagem de áudio (já foi enviada por /api/audio, aqui só se anexa ao chat) ---
        if (data.tipo === 'audio' && data.url) {
            const msg = { id: uuidv4(), autor: sessao.id, nome: sessao.name, audioUrl: data.url, estado: 'enviada', ts: Date.now() };
            const db = lerHistorico();
            db.messages.push(msg);
            gravarHistorico(db);
            broadcast({ tipo: 'mensagem', msg });
            const outro = outraPessoa(sessao.id);
            if (estaOnline(outro.id)) marcarEntregues(outro.id);
            avisar(outro.id, sessao.name, `${sessao.name} mandou um áudio 🎙️`);
            return;
        }

        // --- Mensagem de texto normal ---
        const texto = (data.texto || '').toString().trim().slice(0, 2000);
        if (!texto) return;

        const db = lerHistorico();
        const msg = { id: uuidv4(), autor: sessao.id, nome: sessao.name, texto, estado: 'enviada', ts: Date.now() };
        db.messages.push(msg);
        gravarHistorico(db);
        broadcast({ tipo: 'mensagem', msg });

        const outro = outraPessoa(sessao.id);
        if (estaOnline(outro.id)) marcarEntregues(outro.id);
        avisar(outro.id, sessao.name, texto);

        // O Iray responde se for chamado directamente ("iray", "@iray") —
        // assim não fala por cima de toda a conversa a dois.
        if (/\biray\b/i.test(texto)) {
            broadcast({ tipo: 'digitando', autor: 'iray' });
            const historicoRecente = db.messages.slice(-12);
            const resposta = await perguntarIray(historicoRecente);
            const msgIray = { id: uuidv4(), autor: 'iray', nome: 'Iray', texto: resposta, ts: Date.now() };
            const db2 = lerHistorico();
            db2.messages.push(msgIray);
            gravarHistorico(db2);
            broadcast({ tipo: 'mensagem', msg: msgIray });

            // Se perguntaram "onde está"/"chama-a(o)" pelo Iray, além da
            // resposta normal, avisa a pessoa em causa com um toque mais
            // carinhoso — como pediste no exemplo original.
            if (/\b(onde est[aá]|chama[- ]?(a|o|la|lo)|preciso (dela|dele))\b/i.test(texto)) {
                const msgCarinho = { id: uuidv4(), autor: 'iray', nome: 'Iray', texto: `💌 ${outro.name}, o(a) ${sessao.name} está à tua procura`, carinho: true, ts: Date.now() };
                const db3 = lerHistorico();
                db3.messages.push(msgCarinho);
                gravarHistorico(db3);
                broadcast({ tipo: 'mensagem', msg: msgCarinho });
                avisar(outro.id, 'Iray', `${outro.name}, o(a) ${sessao.name} está à tua procura 😍`);
            }
        }
    });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`💛 Iray App em http://localhost:${PORT}`);
});
